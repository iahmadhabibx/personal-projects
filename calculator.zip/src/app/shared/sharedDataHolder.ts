var SharedData = {
    lastDigitHolder: 0
}

export default SharedData;