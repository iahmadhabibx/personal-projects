var SHARED_DATA = {
    amount: 0
}

export default SHARED_DATA;